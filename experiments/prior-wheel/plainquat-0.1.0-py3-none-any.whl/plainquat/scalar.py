"""Quaternion operations on scalar-first ``(w, x, y, z)`` tuples.

All operations return new tuples or floats. Inputs must contain finite real
numbers. Underflow follows Python float arithmetic; a non-finite result raises
``OverflowError``. Division-dependent operations reject the zero quaternion.
"""

from collections.abc import Iterable
from math import fsum, hypot, isfinite
from numbers import Real

Quaternion = tuple[float, float, float, float]
Vector = tuple[float, float, float]


def _components(values: Iterable[float], length: int, name: str) -> tuple:
    try:
        items = tuple(values)
    except TypeError as exc:
        raise ValueError(f"{name} must be an iterable of {length} real numbers") from exc
    if len(items) != length:
        raise ValueError(f"{name} must contain exactly {length} components")
    if not all(isinstance(value, Real) for value in items):
        raise ValueError(f"{name} must contain finite real numbers")
    try:
        result = tuple(float(value) for value in items)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must contain finite real numbers") from exc
    if not all(isfinite(value) for value in result):
        raise ValueError(f"{name} must contain finite real numbers")
    return result


def _quaternion(q: Iterable[float]) -> Quaternion:
    return _components(q, 4, "quaternion")  # type: ignore[return-value]


def _vector(v: Iterable[float]) -> Vector:
    return _components(v, 3, "vector")  # type: ignore[return-value]


def _checked(values: tuple) -> tuple:
    if not all(isfinite(value) for value in values):
        raise OverflowError("quaternion operation produced a non-finite result")
    return values


def from_xyzw(q: Iterable[float]) -> Quaternion:
    """Convert scalar-last ``(x, y, z, w)`` to scalar-first order."""
    x, y, z, w = _quaternion(q)
    return w, x, y, z


def to_xyzw(q: Iterable[float]) -> Quaternion:
    """Convert scalar-first order to scalar-last ``(x, y, z, w)``."""
    w, x, y, z = _quaternion(q)
    return x, y, z, w


def conjugate(q: Iterable[float]) -> Quaternion:
    """Return the conjugate, preserving the quaternion's magnitude."""
    w, x, y, z = _quaternion(q)
    return w, -x, -y, -z


def multiply(q: Iterable[float], r: Iterable[float]) -> Quaternion:
    """Return the Hamilton product ``q * r`` (``r`` acts first)."""
    w, x, y, z = _quaternion(q)
    a, b, c, d = _quaternion(r)
    return _checked((
        w*a - x*b - y*c - z*d,
        w*b + x*a + y*d - z*c,
        w*c - x*d + y*a + z*b,
        w*d + x*c - y*b + z*a,
    ))  # type: ignore[return-value]


def norm(q: Iterable[float]) -> float:
    """Return the Euclidean norm, using a scaled hypotenuse calculation."""
    result = hypot(*_quaternion(q))
    if not isfinite(result):
        raise OverflowError("quaternion norm is too large for a float")
    return result


def _scaled(q: Quaternion) -> tuple:
    scale = max(abs(value) for value in q)
    if scale == 0.0:
        raise ValueError("zero quaternion has no inverse or normalization")
    parts = tuple(value / scale for value in q)
    return scale, parts


def normalize(q: Iterable[float]) -> Quaternion:
    """Return a unit quaternion; reject zero, NaN, and infinity."""
    _, parts = _scaled(_quaternion(q))
    length = hypot(*parts)
    return tuple(value / length for value in parts)  # type: ignore[return-value]


def inverse(q: Iterable[float]) -> Quaternion:
    """Return the multiplicative inverse of a nonzero quaternion."""
    scale, parts = _scaled(_quaternion(q))
    w, x, y, z = parts
    denominator = sum(value * value for value in parts)
    result = tuple((value / denominator) / scale for value in (w, -x, -y, -z))
    return _checked(result)  # type: ignore[return-value]


def _dot3(a: float, b: float, c: float, x: float, y: float, z: float) -> float:
    """Sum finite component products without avoidable intermediate overflow."""
    terms = [a*x, b*y, c*z]
    terms.sort(key=abs, reverse=True)
    # Add the largest opposite-signed terms first.  fsum otherwise can overflow
    # during its internal accumulation even when the final sum is representable.
    if ((terms[0] > 0.0 and terms[1] > 0.0 and terms[2] < 0.0)
            or (terms[0] < 0.0 and terms[1] < 0.0 and terms[2] > 0.0)):
        terms[1], terms[2] = terms[2], terms[1]
    return fsum(terms)


def rotate(q: Iterable[float], v: Iterable[float]) -> Vector:
    """Actively rotate ``v`` by ``q * (0, v) * inverse(q)``.

    Any nonzero quaternion is valid; its magnitude has no effect. No input is
    normalized. Internally scaling its components avoids unnecessary overflow.
    """
    _, parts = _scaled(_quaternion(q))
    w, x, y, z = parts
    vx, vy, vz = _vector(v)
    w2, x2, y2, z2 = w*w, x*x, y*y, z*z
    denominator = w2 + x2 + y2 + z2
    # Compute each component independently.  A shared vector scale can erase a
    # small component when another one is near the largest representable float.
    def coefficient(value: float) -> float:
        return min(1.0, max(-1.0, value / denominator))

    m00 = coefficient(w2 + x2 - y2 - z2)
    m01 = coefficient(2*(x*y - w*z))
    m02 = coefficient(2*(x*z + w*y))
    m10 = coefficient(2*(x*y + w*z))
    m11 = coefficient(w2 - x2 + y2 - z2)
    m12 = coefficient(2*(y*z - w*x))
    m20 = coefficient(2*(x*z - w*y))
    m21 = coefficient(2*(y*z + w*x))
    m22 = coefficient(w2 - x2 - y2 + z2)
    return _checked((_dot3(m00, m01, m02, vx, vy, vz),
                     _dot3(m10, m11, m12, vx, vy, vz),
                     _dot3(m20, m21, m22, vx, vy, vz)))  # type: ignore[return-value]
