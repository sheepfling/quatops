"""Explicit negative-cross JPL operations; import a representation submodule.

Quaternions use ``(x, y, z, w)`` and represent active right-handed rotations.
Importing this package does not import NumPy.
"""
