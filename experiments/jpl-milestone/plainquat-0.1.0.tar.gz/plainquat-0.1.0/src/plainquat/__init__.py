"""Quaternion operations with explicit conventions and representations.

Choose ``plainquat.hamilton`` or ``plainquat.jpl``, then import the scalar,
namedtuple, dataclass or optional NumPy module. The original top-level backend
modules remain Hamilton for compatibility. This package does not import NumPy.
"""

__version__ = "0.1.0"
