# plainquat

A small, provisional quaternion library with explicit convention and
representation modules. Choose the module that matches your data: there is no
convention flag or automatic backend dispatch. The scalar representations have
no third-party runtime dependencies. This is a local candidate for review, not
a published package or a performance claim.

## Choose a module

Each convention provides the same four representation modules:

| Module | Representation | When it fits |
| --- | --- | --- |
| `scalar` | Plain tuple | Individual quaternions without a named type. |
| `namedtuple` | Immutable `Quaternion` named tuple | Named fields plus tuple indexing, unpacking, and tuple equality. |
| `dataclass` | Frozen, slotted `Quaternion` dataclass | Named fields and a distinct value type with class-sensitive equality. |
| `numpy` | Float64 arrays shaped `(..., 4)` | Batches and broadcasting. |

Import, for example, `plainquat.hamilton.scalar` or `plainquat.jpl.numpy`.
The existing `plainquat.scalar`, `plainquat.namedtuple`, `plainquat.dataclass`,
and `plainquat.numpy` imports retain their Hamilton behavior. Choose a
convention deliberately: a component layout alone does not identify the
multiplication algebra or the meaning of a rotation.

From the project directory, `python -m pip install .` installs the scalar
representations. Use `python -m pip install '.[numpy]'` for the array modules.
NumPy is imported only when a NumPy module is imported. Python 3.9 or newer is
required.

## Conventions

| Property | Hamilton modules | JPL modules |
| --- | --- | --- |
| Stored components | scalar-first `(w, x, y, z)` | scalar-last `(x, y, z, w)` |
| Product vector term | `aw*bv + bw*av + av × bv` | `aw*bv + bw*av - av × bv` |
| Product scalar term | `aw*bw - av · bv` | `aw*bw - av · bv` |
| Rotation action | Active, right-handed `q * (0, v) * inverse(q)` | Active, right-handed `q ⊙ (v, 0) ⊙ inverse(q)` |
| Composition | `multiply(q, r)` applies `r`, then `q` | `multiply(q, r)` applies `r`, then `q` |

Here `av` and `bv` are the vector components and `aw` and `bw` their scalar
components. For a passive coordinate transformation, apply `inverse(q)` to
the vector. Negating every component produces the *same* rotation; it is not
the same operation as taking the inverse.

For the same physical rotation, Hamilton `(w, x, y, z)` corresponds to JPL
`(-x, -y, -z, w)`. Use a JPL module's `from_hamilton` and `to_hamilton` for
this convention conversion. The layout helpers `from_wxyz`, `to_wxyz`,
`from_xyzw`, and `to_xyzw` **only reorder components** within the chosen
convention; they do not negate the vector or change algebra. This distinction
also matters when comparing to SciPy, whose rotation quaternions are
Hamilton: use SciPy scalar-last values `(-jx, -jy, -jz, jw)` for a JPL input.

Convention names are not universal: JPL's own SPICE toolkit uses Hamilton
quaternions. See the [SPICE quaternion convention documentation](https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/qxq_c.html).
The table above defines what these modules mean.

```python
from math import pi
from plainquat.hamilton import scalar as h
from plainquat.jpl import scalar as j

qh = h.from_axis_angle((0, 0, 1, pi / 2))  # wxyz, +z vector part
qj = j.from_hamilton(qh)                    # xyzw, -z vector part
assert j.to_hamilton(qj) == qh
vh = h.rotate(qh, (1, 0, 0))               # approximately (0, 1, 0)
vj = j.rotate(qj, (1, 0, 0))               # approximately (0, 1, 0)
axis_angle = j.to_axis_angle(qj)           # approximately (0, 0, 1, pi/2)
rotvec = j.to_rotvec(qj)                   # approximately (0, 0, pi/2)

# Named values and arrays are chosen explicitly within a convention.
from plainquat.jpl import namedtuple as named
from plainquat.jpl import numpy as qnp
q = named.Quaternion(0, 0, 0, 1)
rotated = qnp.rotate([[0, 0, 0, 1], qj], [1, 0, 0])  # shape (2, 3)
```

## API and numerical behavior

See [API.md](API.md) for operation signatures, validation, conversion and
numerical details. Both conventions offer conjugation, multiplication, norm,
normalization, inverse, rotation, explicit layout conversion, and axis-angle
and rotation-vector conversions. The JPL modules also offer explicit
Hamilton/JPL conversion. Axis-angle is `(ax, ay, az, angle)` in radians;
rotation vectors are axis times angle. These describe the same physical
rotations in both conventions. Quaternion algebra does not normalize inputs;
rotation-representation conversions explicitly normalize as documented.

Inputs must be finite and correctly shaped. Zero quaternions cannot be
normalized, inverted, or used to rotate; zero axes cannot be used in
axis-angle conversion. NumPy validates batches together, broadcasts leading
dimensions, uses float64, preserves input arrays and the caller's
`numpy.seterr` settings, and supports empty batches. Object and complex arrays
are rejected. Arithmetic yielding a non-finite result raises `OverflowError`;
finite underflow and rounding can lose information. Existing extreme
componentwise cancellation and subnormal conversion limits remain documented
in [API.md](API.md) and the [precision investigation](experiments/ROTATION_NUMERICS.md).

The test suite uses SciPy only as a development oracle. Install
`python -m pip install '.[dev]'` for optional test dependencies and run
`PYTHONPATH=src python -m unittest discover -s tests -v`. Conversion to matrices
or Euler angles, interpolation, angular velocities, compiled acceleration, and
performance guarantees are outside this initial scope.
