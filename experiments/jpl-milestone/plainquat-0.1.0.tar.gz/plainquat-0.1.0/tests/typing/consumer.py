"""Installed-wheel typing smoke test; checked by mypy, Pyright, and ty."""

from typing import assert_type

from plainquat import dataclass, namedtuple, scalar

q = (1.0, 0.0, 0.0, 0.0)
assert_type(scalar.norm(q), float)
assert_type(scalar.rotate(q, (1.0, 0.0, 0.0)), tuple[float, float, float])
assert_type(namedtuple.inverse(namedtuple.Quaternion(*q)), namedtuple.Quaternion)
assert_type(dataclass.conjugate(dataclass.Quaternion(*q)), dataclass.Quaternion)
assert_type(scalar.to_axis_angle(q), tuple[float, float, float, float])
assert_type(scalar.to_rotvec(q), tuple[float, float, float])
assert_type(namedtuple.to_axis_angle(q), namedtuple.AxisAngle)
assert_type(namedtuple.to_rotvec(q), namedtuple.RotVec)
assert_type(namedtuple.from_axis_angle(namedtuple.AxisAngle(1, 0, 0, 0)), namedtuple.Quaternion)
assert_type(dataclass.to_axis_angle(q), dataclass.AxisAngle)
assert_type(dataclass.to_rotvec(q), dataclass.RotVec)
assert_type(dataclass.from_rotvec(dataclass.RotVec(0, 0, 0)), dataclass.Quaternion)

from plainquat.hamilton import dataclass as h_dataclass
from plainquat.hamilton import namedtuple as h_namedtuple
from plainquat.hamilton import scalar as h_scalar
from plainquat.jpl import dataclass as j_dataclass
from plainquat.jpl import namedtuple as j_namedtuple
from plainquat.jpl import scalar as j_scalar

assert_type(h_scalar.to_wxyz(q), tuple[float, float, float, float])
assert_type(h_namedtuple.from_wxyz(q), h_namedtuple.Quaternion)
assert_type(h_dataclass.to_rotvec(q), h_dataclass.RotVec)
assert_type(j_scalar.from_hamilton(q), tuple[float, float, float, float])
assert_type(j_namedtuple.from_hamilton(q), j_namedtuple.Quaternion)
assert_type(j_dataclass.to_rotvec((0, 0, 0, 1)), j_dataclass.RotVec)
