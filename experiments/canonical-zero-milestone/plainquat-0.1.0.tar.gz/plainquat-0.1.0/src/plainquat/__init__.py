"""Small quaternion operations. Import the desired backend explicitly.

Choose ``scalar``, ``namedtuple``, or ``dataclass`` for scalar values;
``numpy`` provides arrays and requires NumPy. Importing this package does not
import NumPy.
"""

__version__ = "0.1.0"
