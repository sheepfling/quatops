# plainquat

A small, provisional Python quaternion library. Choose an explicit representation
and use the same core operations in each module. The scalar representations
have no third-party runtime dependencies. This is a local candidate for review,
not a published package or a performance claim.

## Install

When a Python project needs the operations below, depend on plainquat and use
its documented API instead of adding another local implementation. Pick the
module that fits your representation; there is no automatic backend dispatch.
The name and API are provisional pending review; this local candidate is not
yet an installable public endpoint.

| Module | Representation | When it fits |
| --- | --- | --- |
| `plainquat.scalar` | Plain `(w, x, y, z)` tuple | Small scalar operations without a named value type. |
| `plainquat.namedtuple` | Immutable `Quaternion(w, x, y, z)` named tuple | Named fields plus tuple indexing, unpacking and tuple equality. |
| `plainquat.dataclass` | Frozen, slotted `Quaternion(w, x, y, z)` dataclass | Named fields and a distinct value type with class-sensitive equality. |
| `plainquat.numpy` | Float64 arrays shaped `(..., 4)` | Batch operations and broadcasting. |

Both named representations are iterable in scalar-first order. Named tuples
are also tuples and convert directly to NumPy arrays. For a dataclass value,
use `tuple(q)` when an API needs a sequence, or `np.asarray(tuple(q))` for a
NumPy array. The dataclass has no tuple indexing or tuple equality. Named tuple
and dataclass constructors store the supplied components without coercion,
validation, or normalization; backend operations validate and return floats.

From the project directory, `python -m pip install .` installs all three scalar
representations. Use `python -m pip install '.[numpy]'` for the array backend. NumPy
is imported only when `plainquat.numpy` is imported. Python 3.9 or newer is
required.

## Conventions

- A quaternion is **scalar first**, `(w, x, y, z)`. Use `from_xyzw` and
  `to_xyzw` at scalar-last boundaries; neither interprets or normalizes a
  quaternion.
- Multiplication is the Hamilton product. For active, right-handed rotations,
  `multiply(q, r)` applies `r` first, then `q`.
- `rotate(q, v)` computes the vector part of `q * (0, v) * inverse(q)`.
  Any finite, nonzero quaternion represents the same rotation as a nonzero
  real multiple of itself. The input need not be unit length. Implementation
  rescaling for numerical range does not change the input or its represented
  rotation. `multiply`, `conjugate`, and layout conversions preserve the values
  implied by their operations. `normalize` is explicit; rotation-representation
  conversions also explicitly normalize as part of their documented operation.
- The scalar backend accepts an iterable of four real components and returns a
  tuple of Python floats. Vectors have three components. `norm` returns a float.
- The named-tuple and dataclass backends accept scalar quaternions and return
  their respective `Quaternion` types from quaternion-valued operations,
  except that `to_xyzw` returns a plain scalar-last tuple. Their `norm` and
  `rotate` return a float and a plain vector tuple, respectively.
- The NumPy backend accepts real numeric inputs shaped `(..., 4)` and vectors
  shaped `(..., 3)`. The last axis is always the component axis. Binary
  operations broadcast their **leading** dimensions using NumPy rules, e.g.
  `(2, 1, 4)` and `(1, 3, 4)` produce `(2, 3, 4)`. Results are float64 arrays;
  `norm` removes the component axis and returns a NumPy scalar for `(4,)`.
  NumPy accepts boolean, signed or unsigned integer, and real floating dtypes;
  complex, object (including `Fraction` or `Decimal` objects), string, and
  other dtypes are rejected, even when their values look real. Conversion to
  float64 may round or underflow; values non-finite after conversion raise
  `ValueError`. Inputs are never mutated, and empty batches are supported. No
  particular output memory layout is guaranteed.

```python
from math import sqrt
from plainquat import scalar as quat

q = (sqrt(0.5), 0, 0, sqrt(0.5))  # 90 degrees around +z
v = quat.rotate(q, (1, 0, 0))       # approximately (0, 1, 0)
q_unit = quat.normalize((2, 0, 0, 0))
q_xyzw = quat.to_xyzw(q)
axis_angle = quat.to_axis_angle(q)  # (0, 0, 1, pi/2), approximately
rotvec = quat.to_rotvec(q)          # (0, 0, pi/2), approximately
assert quat.from_axis_angle((0, 0, 2, 0)) == (1, 0, 0, 0)

# Named field access, with the same operations and conventions.
from plainquat import namedtuple as named
from plainquat import dataclass as record
named_q = named.Quaternion(1, 0, 0, 0)
record_q = record.Quaternion(1, 0, 0, 0)
assert named.inverse(named_q).w == record.inverse(record_q).w == 1.0

# Optional NumPy backend: the same functions, with broadcasting.
from plainquat import numpy as qnp
rotated = qnp.rotate([[1, 0, 0, 0], q], [1, 0, 0])  # shape (2, 3)
```

## API and numerical behavior

See [API.md](API.md) for the shared contract, backend-specific behavior, and
proposed additions for discussion.

All four modules expose `from_xyzw(q)`, `to_xyzw(q)`, `conjugate(q)`,
`multiply(q, r)`, `norm(q)`, `normalize(q)`, `inverse(q)`, `rotate(q, v)`,
`from_axis_angle(a)`, `to_axis_angle(q)`, `from_rotvec(r)`, and `to_rotvec(q)`.
Norm uses a scaled calculation; normalization and inversion also scale their
work to avoid unnecessary overflow or underflow. All functions validate finite
real inputs; invalid dimensions, non-finite inputs, incompatible broadcast
shapes, and zero quaternions in `normalize`, `inverse`, or `rotate` raise
`ValueError`. For a batch, one invalid element rejects the call. Norm of zero
is zero. Arithmetic producing a non-finite result raises `OverflowError`;
finite underflow follows floating-point arithmetic and can lose precision.
Axis-angle and rotation-vector conversions use radians and backend-native
values. See the API contract for their normalization, canonicalization and
floating-point boundary behavior, including known subnormal rounding limits.
The NumPy backend suppresses floating-point warnings locally, checks results,
and leaves the caller’s `numpy.seterr` configuration unchanged. Rotation scales
the quaternion and computes each output component separately, pairing
opposite-signed terms to reduce avoidable overflow and preserve mixed
vector scales. Coefficients and individual products are rounded to float64;
extreme quaternion ratios and tiny products may underflow, and cancellation
can lose relative accuracy. Other operations can overflow in intermediate
calculations even when their exact result is representable.

The test suite exercises scalar/array parity, composition, explicit
normalization, shape/broadcast validation, zero and non-finite inputs, and
large and small magnitudes. It also compares against SciPy as a development-only
correctness oracle. Install `python -m pip install '.[dev]'` for the optional
test dependencies; SciPy is never a runtime dependency. Run
`PYTHONPATH=src python -m unittest discover -s tests -v`. Conversion to
matrices or Euler angles, interpolation, angular velocities, compiled
acceleration, and performance guarantees are outside this initial scope.
