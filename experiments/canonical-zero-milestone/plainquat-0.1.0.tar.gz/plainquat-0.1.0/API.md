# Shared API contract

This is the **implemented, provisional** common contract of `plainquat.scalar`,
`plainquat.namedtuple`, `plainquat.dataclass`, and `plainquat.numpy`. Import
and call a module explicitly; no backend is selected automatically. For a
quick start, see the [README](README.md).

## Representations and construction

| Module | Construct a scalar-first value | Quaternion-valued operation results | Other capabilities |
| --- | --- | --- | --- |
| `scalar` | `(w, x, y, z)` or another four-component iterable | A plain tuple of four Python floats | Scalar values, no NumPy required |
| `namedtuple` | `namedtuple.Quaternion(w, x, y, z)` | That module's `Quaternion`, with float fields | Immutable, named fields, indexing, unpacking and tuple equality |
| `dataclass` | `dataclass.Quaternion(w, x, y, z)` | That module's frozen, slotted `Quaternion`, with float fields | Immutable, named fields, iterable in wxyz order, class-sensitive equality |
| `numpy` | A real numeric array or array-like with shape `(..., 4)` | A float64 array with final dimension 4 | Leading-dimension broadcasting and empty batches |

There is no common constructor function. Both named `Quaternion` constructors
store the components as supplied, without validation, conversion, or
normalization; validation is performed by operations. Their iteration order is
`w, x, y, z`. A dataclass value is not a tuple or an indexable sequence; use
`tuple(q)` when a consumer requires one, including for NumPy array conversion.

## Operations

`q` and `r` are quaternions in the selected backend's representation. `v` is a
three-component vector. The names and mathematical meanings below are the same
in every module; see the return conventions beneath the table.

| Signature | Meaning | Result |
| --- | --- | --- |
| `from_xyzw(q)` | Reorder scalar-last `(x, y, z, w)` to scalar-first `(w, x, y, z)` | Quaternion |
| `to_xyzw(q)` | Reorder scalar-first `(w, x, y, z)` to scalar-last `(x, y, z, w)` | Four scalar-last components |
| `conjugate(q)` | Conjugate `(w, x, y, z)` to `(w, -x, -y, -z)` | Quaternion |
| `multiply(q, r)` | Hamilton product `q * r` | Quaternion |
| `norm(q)` | Euclidean norm | Real scalar or array of scalars |
| `normalize(q)` | Divide by the norm; `q` must be nonzero | Unit quaternion |
| `inverse(q)` | Multiplicative inverse; `q` must be nonzero | Quaternion |
| `rotate(q, v)` | Vector part of `q * (0, v) * inverse(q)`; `q` must be nonzero | Three-component vector |
| `from_axis_angle(a)` | Convert `(axis_x, axis_y, axis_z, radians)` to a canonical unit quaternion | Quaternion |
| `to_axis_angle(q)` | Convert a nonzero quaternion to a canonical unit axis and principal angle | AxisAngle |
| `from_rotvec(r)` | Convert axis-times-angle radians to a canonical unit quaternion | Quaternion |
| `to_rotvec(q)` | Convert a nonzero quaternion to a principal rotation vector | RotVec |

For the three scalar modules, inputs are iterables of four real components for
quaternions and three for vectors. `to_xyzw` always returns a plain tuple, even
for the named representations, because its components no longer match the
scalar-first field labels. `norm` returns a Python float and `rotate` a plain
three-float tuple. Quaternion-valued operations use the result types above.

For NumPy, quaternion and vector inputs have trailing dimensions 4 and 3,
respectively. Array-like inputs must infer a boolean, signed or unsigned
integer, or real floating dtype. Complex, object (including `Fraction` or
`Decimal`), string, and other dtypes are rejected even if their values look
real. Values are cast to float64, which can round or underflow; conversion to a
non-finite float64 raises `ValueError`. Binary operations broadcast leading
dimensions according to NumPy rules. Thus `(2, 1, 4)` multiplied by `(1, 3, 4)`
returns `(2, 3, 4)`; rotating `(2, 1, 4)` quaternions by `(1, 3, 3)` vectors
returns `(2, 3, 3)`. `norm` removes the final axis and yields a NumPy scalar for
an input of shape `(4,)`. `to_xyzw` returns a float64 array with a final
dimension of 4. No output memory layout is guaranteed.

## Axis-angle and rotation-vector conversions

These are provisional candidate policies. AxisAngle is flat `(ax, ay, az,
angle)` in radians; RotVec is `(x, y, z)` with direction equal to the axis and
length equal to the angle in radians. The scalar backend returns plain tuples;
`namedtuple` and `dataclass` expose their own `AxisAngle` and `RotVec` classes;
NumPy returns float64 arrays of shape `(..., 4)` and `(..., 3)`. Constructors
store their arguments as supplied; operations validate them. Each conversion is
unary and preserves NumPy leading batch dimensions, including empty batches;
there is no independent axis/angle broadcasting in the flat layout.

`from_axis_angle` explicitly normalizes the supplied finite nonzero axis, even
at zero angle, and rejects a zero axis. A zero RotVec is valid and means identity.
Quaternion-to-representation conversion explicitly extracts a rotation from a
finite nonzero quaternion without requiring unit length; it does not preserve
the input's magnitude or the sign distinction between `q` and `-q`. Conversion
to quaternion returns a canonical unit quaternion. These are conversion
semantics, not implicit normalization of quaternion arithmetic.

Output axis-angle and rotation-vector angles use a principal range `[0, pi]`.
Identity uses axis +X and zero angle or the zero RotVec. Canonical quaternion
sign has `w > 0`; when the original scalar component is exactly zero, the first
nonzero x/y/z component is positive. Signed zeros in canonical outputs become
positive zero. This half-turn tie is exact, without a tolerance. `from_axis_angle`
treats input `+math.pi` or `-math.pi` as an exact half-turn; `from_rotvec` does
so when its computed float64 norm equals `math.pi`. Adjacent angle values are
not snapped. Scalar and NumPy vector norm calculations can round a near-`pi`
norm differently by an ulp, so their raw quaternion components can differ at
this boundary even when the represented rotations agree within rounding.
`to_axis_angle` can return an angle rounded to `pi` even when the original nonzero scalar part means its
axis need not satisfy the exact-half-turn sign tie. At extreme axis component
ratios, the first nonzero component used for the exact-half-turn tie can also
underflow in the returned axis; sign selection still uses the original input.
A round trip preserves the rotation only to the extent that the intermediate
representation can express it, not the raw quaternion components.

All finite input angles are accepted. Outside the exact `pi` rule, sine and
cosine are evaluated on the half-angle without explicit modulo reduction; for
very large arguments the precision of platform/NumPy trigonometric functions
and their argument reduction is not guaranteed across platforms. If a RotVec
norm cannot be represented as a float, `from_rotvec` raises `OverflowError`.
No arbitrary small-angle threshold snaps a representable rotation to identity.
Nevertheless, finite precision has limits: the half-angle of a smallest
subnormal RotVec cannot be represented in a quaternion and may round to zero;
a quaternion whose rotation angle itself rounds to zero converts to identity.
Canonical quaternion input sign is chosen before scaling. Tiny or extreme
ratios can still lose information, so componentwise precision is not guaranteed.
For example, if `u` is the smallest positive binary64 subnormal, the current
`from_rotvec((5*u, 5*u, 0))` produces quaternion vector components `3*u`; the
exact values are just below `2.5*u` and round to `2*u`. This is a documented
double-rounding limit, not a correctly-rounded conversion guarantee.

## Conventions and errors

- Quaternion components are scalar first except at the explicit `xyzw`
  conversion boundary. Rotation is active and right-handed. `multiply(q, r)`
  composes rotations so that `r` acts first and `q` second.
- Quaternion algebra has no implicit normalization. In particular, `rotate` uses the inverse
  and accepts any finite nonzero quaternion: nonzero scalar multiples represent
  the same rotation. Internal scaling limits avoidable overflow without
  modifying the input or its represented rotation.
- Operations reject malformed component shapes or counts, non-real or
  non-finite inputs, incompatible broadcast dimensions, and zero quaternions
  in `normalize`, `inverse`, and `rotate` with `ValueError`. One invalid entry
  rejects a whole NumPy call. `norm` of zero is zero.
- Arithmetic that produces a non-finite result raises `OverflowError`. Norm,
  normalization, and inverse use scaled calculations to reduce avoidable
  overflow or underflow; finite underflow and rounding follow floating-point
  arithmetic. Rotation scales the quaternion and forms each output component
  separately, combining opposite-signed terms to reduce avoidable overflow.
  Coefficients and individual products are rounded to float64; extreme
  quaternion ratios and tiny products can underflow, and cancellation can lose
  relative accuracy. In particular, `rotate((5, 12, 13, 0), (1e308, 1, 1))`
  currently returns a first component near `1.11e292` instead of `17/13`.
  See [the precision investigation](experiments/ROTATION_NUMERICS.md) for a
  second example and measured alternatives. Other operations can overflow in intermediate calculations
  even when their exact result would be representable. NumPy suppresses floating-point warnings
  locally, checks results, and preserves the caller's `numpy.seterr`
  configuration. Inputs are not mutated.

## Possible additions, not implemented

These are candidates for a later decision, not part of the current API:

- **Rotation matrix conversion** could ease interoperability; it needs explicit
  matrix shape, active/passive, handedness, and invalid-matrix policies.
- **Interpolation** such as spherical interpolation could support animation; it
  needs decisions about shortest-path sign choice and endpoint behavior.

The current matrix is deliberately limited to the operations implemented and
covered by conformance tests. It does not claim to be a complete quaternion API.
