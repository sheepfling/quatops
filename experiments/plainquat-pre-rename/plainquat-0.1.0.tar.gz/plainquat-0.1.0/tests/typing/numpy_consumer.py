"""Installed-wheel NumPy layout type checks with the optional NumPy extra."""

from typing import Any, assert_type

from numpy.typing import NDArray

from plainquat.hamilton import numpy_wxyz as hw
from plainquat.hamilton import numpy_xyzw as hx
from plainquat.jpl import numpy_wxyz as jw
from plainquat.jpl import numpy_xyzw as jx

q = (1.0, 0.0, 0.0, 0.0)
assert_type(hw.rotate(q, (1.0, 0.0, 0.0)), NDArray[Any])
assert_type(hx.to_axis_angle((0.0, 0.0, 0.0, 1.0)), NDArray[Any])
assert_type(jw.from_hamilton(q), NDArray[Any])
assert_type(jx.to_hamilton((0.0, 0.0, 0.0, 1.0)), NDArray[Any])
